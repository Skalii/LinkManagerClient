create function bookmarks__delete_tr() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE profiles
  SET ids_bookmark = ids_bookmark - OLD.id_site
  WHERE id_profile = OLD.id_profile;

  RETURN OLD;
END;
$$;
