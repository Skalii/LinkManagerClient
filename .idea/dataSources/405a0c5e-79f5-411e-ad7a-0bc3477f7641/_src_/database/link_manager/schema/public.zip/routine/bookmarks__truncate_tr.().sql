create function bookmarks__truncate_tr() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE profiles
  SET ids_bookmark = ARRAY[]::INTEGER[];

  RETURN NULL;
END;
$$;
